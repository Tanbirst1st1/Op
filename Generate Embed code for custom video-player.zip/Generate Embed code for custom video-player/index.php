<?php
header("location:/admin/");

?>